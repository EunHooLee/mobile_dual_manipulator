docker run -itd --name gqcnn whdnddh/deeplab-gqcnn:1.0 /bin/bash
